/**
 * Pure domain & animation math helpers for the Walima invitation.
 * Decoupled from DOM APIs so they can be verified deterministically with node:test.
 */

export const TARGET_EVENT_DATE_COMPONENTS = Object.freeze({
  year: 2026,
  monthIndex: 11, // December (0-indexed)
  day: 20,
  hour: 13, // 1:00 PM
  minute: 0,
  second: 0,
});

export const SCRATCH_REVEAL_THRESHOLD = 0.45;

export const AUDIO_TRACK_SRC = '/assets/aistudio/Bismillah_MP3_160K__93cc5182.mp3';

/**
 * Determine next audio playback state and accessible label when toggled.
 * @param {boolean} currentlyPlaying
 * @returns {{ shouldPlay: boolean, ariaLabel: string, pressed: string }}
 */
export function getNextAudioState(currentlyPlaying) {
  const shouldPlay = !currentlyPlaying;
  return {
    shouldPlay,
    ariaLabel: shouldPlay ? 'Mute background music' : 'Play background music',
    pressed: shouldPlay ? 'true' : 'false',
  };
}

/**
 * Create the local Date object representing Sunday, 20 December 2026 at 1:00 PM.
 * @returns {Date}
 */
export function createWalimaTargetDate() {
  const { year, monthIndex, day, hour, minute, second } = TARGET_EVENT_DATE_COMPONENTS;
  return new Date(year, monthIndex, day, hour, minute, second, 0);
}

/**
 * Calculate remaining days, hours, minutes, seconds between `now` and `target`.
 * @param {Date | number} now
 * @param {Date | number} target
 * @returns {{ days: number, hours: number, mins: number, secs: number, passed: boolean }}
 */
export function calculateCountdown(now, target) {
  const nowMs = now instanceof Date ? now.getTime() : Number(now);
  const targetMs = target instanceof Date ? target.getTime() : Number(target);
  const diffMs = targetMs - nowMs;

  if (!Number.isFinite(diffMs) || diffMs <= 0) {
    return { days: 0, hours: 0, mins: 0, secs: 0, passed: true };
  }

  const totalSeconds = Math.floor(diffMs / 1000);
  const days = Math.floor(totalSeconds / 86400);
  const hours = Math.floor((totalSeconds % 86400) / 3600);
  const mins = Math.floor((totalSeconds % 3600) / 60);
  const secs = totalSeconds % 60;

  return { days, hours, mins, secs, passed: false };
}

/**
 * Format a countdown integer with a minimum of two digits.
 * @param {number} value
 * @returns {string}
 */
export function padTwoDigits(value) {
  const safe = Math.max(0, Math.floor(value));
  return safe < 10 ? `0${safe}` : String(safe);
}

/**
 * Compute fraction of transparent (scratched) pixels from an RGBA pixel buffer.
 * @param {Uint8ClampedArray | number[]} rgbaData
 * @param {number} [pixelStride=4] Sample every Nth pixel for speed
 * @returns {number} Fraction between 0 and 1
 */
export function computeScratchCoverage(rgbaData, pixelStride = 4) {
  if (!rgbaData || rgbaData.length < 4) return 0;
  const step = Math.max(1, Math.floor(pixelStride)) * 4;
  let sampled = 0;
  let cleared = 0;

  for (let i = 3; i < rgbaData.length; i += step) {
    sampled += 1;
    if (rgbaData[i] < 128) {
      cleared += 1;
    }
  }

  return sampled === 0 ? 0 : cleared / sampled;
}

/**
 * Determine if scratched fraction meets or exceeds the auto-reveal threshold.
 * @param {number} coverage
 * @param {number} [threshold=SCRATCH_REVEAL_THRESHOLD]
 * @returns {boolean}
 */
export function shouldAutoRevealScratch(coverage, threshold = SCRATCH_REVEAL_THRESHOLD) {
  return coverage >= threshold;
}

/**
 * Determine optimal lightweight star particle count for viewport dimensions.
 * Keeps mobile frames smooth and prevents overcrowding.
 * @param {number} width
 * @param {number} height
 * @returns {number}
 */
export function getOptimalStarCount(width, height) {
  const area = Math.max(1, width * height);
  const computed = Math.round(area / 22000);
  return Math.min(72, Math.max(28, computed));
}

const STAR_SHAPES = ['dust', 'four-point', 'six-point'];
const STAR_COLORS = ['#FFFFFF', '#F8F8F8', '#DDE0E3', '#C5C9CC'];

/**
 * Create a single silver-white star particle.
 * @param {number} width
 * @param {number} height
 * @param {boolean} [spawnAtTop=false]
 * @param {() => number} [rng=Math.random]
 */
export function createStarParticle(width, height, spawnAtTop = false, rng = Math.random) {
  const shapeRoll = rng();
  const shape =
    shapeRoll < 0.55 ? STAR_SHAPES[0] : shapeRoll < 0.85 ? STAR_SHAPES[1] : STAR_SHAPES[2];

  const baseSize =
    shape === 'dust' ? 0.8 + rng() * 1.4 : shape === 'four-point' ? 1.8 + rng() * 2.1 : 2.1 + rng() * 2.2;

  return {
    x: rng() * width,
    y: spawnAtTop ? -12 - rng() * 40 : rng() * height,
    size: baseSize,
    vy: 14 + rng() * 24, // px per second gentle descent
    swayAmp: 4 + rng() * 11,
    swayFreq: 0.4 + rng() * 0.8,
    twinkleFreq: 1.1 + rng() * 2.4,
    phase: rng() * Math.PI * 2,
    baseAlpha: 0.25 + rng() * 0.55,
    blur: rng() < 0.35 ? 2 : 4,
    shape,
    color: STAR_COLORS[Math.floor(rng() * STAR_COLORS.length)],
  };
}

/**
 * Advance a star particle by `dtSeconds`, wrapping gracefully at bottom.
 * @param {ReturnType<typeof createStarParticle>} star
 * @param {number} dtSeconds
 * @param {number} elapsedSeconds
 * @param {number} width
 * @param {number} height
 * @param {() => number} [rng=Math.random]
 */
export function stepStarParticle(star, dtSeconds, elapsedSeconds, width, height, rng = Math.random) {
  const clampedDt = Math.min(0.1, Math.max(0, dtSeconds));
  star.y += star.vy * clampedDt;
  star.x += Math.sin(elapsedSeconds * star.swayFreq + star.phase) * star.swayAmp * clampedDt;

  if (star.y > height + 16) {
    star.y = -12 - rng() * 24;
    star.x = rng() * width;
  } else if (star.x < -16) {
    star.x = width + 12;
  } else if (star.x > width + 16) {
    star.x = -12;
  }

  // Smooth fade-in near top and fade-out near bottom, plus gentle twinkle
  const topFade = Math.min(1, Math.max(0, (star.y + 12) / Math.max(40, height * 0.14)));
  const bottomFade = Math.min(1, Math.max(0, (height + 12 - star.y) / Math.max(40, height * 0.16)));
  const twinkle = 0.55 + 0.45 * Math.sin(elapsedSeconds * star.twinkleFreq + star.phase);
  const alpha = Math.max(0, Math.min(1, star.baseAlpha * topFade * bottomFade * twinkle));

  return alpha;
}

/**
 * Build Google Maps search link for the Walima venue.
 * @param {string} venue
 * @param {string} address
 * @returns {string}
 */
export function buildGoogleMapsUrl(venue, address) {
  const query = encodeURIComponent(`${venue}, ${address}`.trim());
  return `https://www.google.com/maps/search/?api=1&query=${query}`;
}
