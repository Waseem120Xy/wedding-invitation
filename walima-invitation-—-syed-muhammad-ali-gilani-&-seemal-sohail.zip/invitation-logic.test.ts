import test from 'node:test';
import assert from 'node:assert/strict';
import {
  createWalimaTargetDate,
  calculateCountdown,
  padTwoDigits,
  computeScratchCoverage,
  shouldAutoRevealScratch,
  getOptimalStarCount,
  createStarParticle,
  stepStarParticle,
  buildGoogleMapsUrl,
  AUDIO_TRACK_SRC,
  getNextAudioState,
} from './invitation-logic.js';

test('Walima target date matches Sunday 20 Dec 2026 at 1:00 PM local time', () => {
  const target = createWalimaTargetDate();
  assert.equal(target.getFullYear(), 2026);
  assert.equal(target.getMonth(), 11);
  assert.equal(target.getDate(), 20);
  assert.equal(target.getDay(), 0); // Sunday
  assert.equal(target.getHours(), 13);
  assert.equal(target.getMinutes(), 0);
  assert.equal(target.getSeconds(), 0);
});

test('calculateCountdown accurately computes remaining days, hours, mins, secs', () => {
  const target = new Date(2026, 11, 20, 13, 0, 0);
  const now = new Date(2026, 11, 18, 10, 45, 30); // 2 days, 2 hours, 14 mins, 30 secs before
  const result = calculateCountdown(now, target);

  assert.deepEqual(result, {
    days: 2,
    hours: 2,
    mins: 14,
    secs: 30,
    passed: false,
  });
});

test('calculateCountdown handles passed target dates cleanly', () => {
  const target = new Date(2026, 11, 20, 13, 0, 0);
  const now = new Date(2026, 11, 20, 14, 0, 0);
  const result = calculateCountdown(now, target);

  assert.deepEqual(result, {
    days: 0,
    hours: 0,
    mins: 0,
    secs: 0,
    passed: true,
  });
});

test('padTwoDigits formats single digits with leading zero and preserves multi-digit numbers', () => {
  assert.equal(padTwoDigits(0), '00');
  assert.equal(padTwoDigits(7), '07');
  assert.equal(padTwoDigits(36), '36');
  assert.equal(padTwoDigits(120), '120');
});

test('computeScratchCoverage calculates transparent pixel percentage and threshold trigger', () => {
  // 4 pixels: 2 transparent (alpha=0), 2 opaque (alpha=255) -> 50% coverage
  const rgba = new Uint8ClampedArray([
    200, 200, 200, 0,
    200, 200, 200, 255,
    200, 200, 200, 0,
    200, 200, 200, 255,
  ]);
  const coverage = computeScratchCoverage(rgba, 1);
  assert.equal(coverage, 0.5);
  assert.equal(shouldAutoRevealScratch(coverage), true);
  assert.equal(shouldAutoRevealScratch(0.44), false);
  assert.equal(shouldAutoRevealScratch(0.45), true);
});

test('star particle system creates only silver-white particles and wraps downward motion', () => {
  const countMobile = getOptimalStarCount(390, 844);
  const countDesktop = getOptimalStarCount(1440, 900);
  assert.ok(countMobile >= 28 && countMobile <= 72);
  assert.ok(countDesktop >= countMobile && countDesktop <= 72);

  const star = createStarParticle(400, 800, false, () => 0.5);
  assert.ok(['#FFFFFF', '#F8F8F8', '#DDE0E3', '#C5C9CC'].includes(star.color));
  assert.ok(['dust', 'four-point', 'six-point'].includes(star.shape));

  star.y = 815;
  const alpha = stepStarParticle(star, 0.1, 1.0, 400, 800, () => 0.5);
  assert.ok(star.y < 0); // wrapped back near top
  assert.ok(alpha >= 0 && alpha <= 1);
});

test('buildGoogleMapsUrl encodes venue and address accurately', () => {
  const url = buildGoogleMapsUrl('Montage Event Complex', 'Executive Block, Gulberg Greens, Islamabad');
  assert.ok(url.startsWith('https://www.google.com/maps/search/?api=1&query='));
  assert.ok(url.includes('Montage%20Event%20Complex'));
  assert.ok(url.includes('Islamabad'));
});

test('background audio track path and toggle helper return expected state', () => {
  assert.equal(AUDIO_TRACK_SRC, '/assets/aistudio/Bismillah_MP3_160K__93cc5182.mp3');
  assert.deepEqual(getNextAudioState(false), {
    shouldPlay: true,
    ariaLabel: 'Mute background music',
    pressed: 'true',
  });
  assert.deepEqual(getNextAudioState(true), {
    shouldPlay: false,
    ariaLabel: 'Play background music',
    pressed: 'false',
  });
});
