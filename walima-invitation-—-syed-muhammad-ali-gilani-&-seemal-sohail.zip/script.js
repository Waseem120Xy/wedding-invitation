import {
  createWalimaTargetDate,
  calculateCountdown,
  padTwoDigits,
  computeScratchCoverage,
  shouldAutoRevealScratch,
  getOptimalStarCount,
  createStarParticle,
  stepStarParticle,
  getNextAudioState,
} from './invitation-logic.js';

/* ==========================================================================
   0. BACKGROUND MUSIC CONTROLLER
   ========================================================================== */

function initBackgroundAudio() {
  const audio = document.getElementById('bg-music');
  const toggleBtn = document.getElementById('audio-toggle-btn');

  if (!(audio instanceof HTMLAudioElement) || !toggleBtn) {
    return {
      startFromGesture: () => {},
      showControl: () => {},
    };
  }

  audio.volume = 0.72;
  let userPaused = false;
  let isPlaying = false;

  function syncButtonUI(playing) {
    isPlaying = playing;
    toggleBtn.dataset.playing = playing ? 'true' : 'false';
    toggleBtn.setAttribute('aria-pressed', playing ? 'true' : 'false');
    toggleBtn.setAttribute(
      'aria-label',
      playing ? 'Mute background music' : 'Play background music',
    );
  }

  function showControl() {
    toggleBtn.hidden = false;
  }

  function startPlayback() {
    const playPromise = audio.play();
    if (playPromise && typeof playPromise.then === 'function') {
      playPromise
        .then(() => {
          userPaused = false;
          syncButtonUI(true);
        })
        .catch(() => {
          // Browser blocked autoplay; user can start via toggle button
          syncButtonUI(false);
        });
    } else {
      userPaused = false;
      syncButtonUI(!audio.paused);
    }
  }

  function startFromGesture() {
    showControl();
    if (!userPaused) {
      startPlayback();
    }
  }

  toggleBtn.addEventListener('click', () => {
    const next = getNextAudioState(isPlaying);
    if (next.shouldPlay) {
      userPaused = false;
      startPlayback();
    } else {
      userPaused = true;
      audio.pause();
      syncButtonUI(false);
    }
  });

  audio.addEventListener('play', () => syncButtonUI(true));
  audio.addEventListener('pause', () => syncButtonUI(false));

  document.addEventListener('visibilitychange', () => {
    if (document.hidden) {
      if (!audio.paused) {
        audio.pause();
      }
    } else if (!userPaused && document.body.dataset.curtain === 'open') {
      startPlayback();
    }
  });

  return { startFromGesture, showControl };
}

/* ==========================================================================
   1. ANIMATED CURTAIN COVER & MEDALLION INTERACTION
   ========================================================================== */

function initCurtainCover(audioController) {
  const cover = document.getElementById('curtain-cover');
  const openBtn = document.getElementById('open-invitation-btn');
  if (!cover || !openBtn) return;

  let isOpening = false;
  let isOpened = false;

  const params = new URLSearchParams(window.location.search);
  if (params.get('autostart') === '1') {
    isOpened = true;
    cover.classList.add('is-opening', 'is-opened');
    cover.setAttribute('aria-hidden', 'true');
    document.body.classList.remove('curtain-locked');
    document.body.dataset.curtain = 'open';
    audioController.showControl();
    return;
  }

  function triggerOpen() {
    if (isOpening || isOpened) return;
    isOpening = true;
    openBtn.disabled = true;

    // Start music directly inside the tap gesture so browsers allow playback
    audioController.startFromGesture();

    cover.classList.add('is-opening');
    document.body.dataset.curtain = 'opening';

    const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const durationMs = reducedMotion ? 40 : 1420;

    window.setTimeout(() => {
      isOpened = true;
      cover.classList.add('is-opened');
      cover.setAttribute('aria-hidden', 'true');
      document.body.classList.remove('curtain-locked');
      document.body.dataset.curtain = 'open';
    }, durationMs);
  }

  openBtn.addEventListener('click', triggerOpen);
}

/* ==========================================================================
   2. SHINING SILVER-WHITE STAR PARTICLE SYSTEM (NO FLOWER PETALS)
   ========================================================================== */

function initStarfield() {
  const canvas = document.getElementById('starfield-canvas');
  if (!(canvas instanceof HTMLCanvasElement)) return;

  const ctx = canvas.getContext('2d');
  if (!ctx) return;

  const reducedMotionQuery = window.matchMedia('(prefers-reduced-motion: reduce)');
  let width = window.innerWidth;
  let height = window.innerHeight;
  let dpr = Math.min(window.devicePixelRatio || 1, 2);
  let stars = [];
  let rafId = null;
  let lastTime = performance.now();
  const startTime = lastTime;

  function resizeCanvas() {
    width = window.innerWidth;
    height = window.innerHeight;
    dpr = Math.min(window.devicePixelRatio || 1, 2);

    canvas.width = Math.floor(width * dpr);
    canvas.height = Math.floor(height * dpr);
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

    const targetCount = getOptimalStarCount(width, height);
    if (stars.length === 0) {
      stars = Array.from({ length: targetCount }, () => createStarParticle(width, height, false));
    } else if (stars.length < targetCount) {
      while (stars.length < targetCount) {
        stars.push(createStarParticle(width, height, false));
      }
    } else if (stars.length > targetCount) {
      stars.length = targetCount;
    }
  }

  function drawStar(star, alpha) {
    if (alpha <= 0.01) return;

    ctx.save();
    ctx.translate(star.x, star.y);
    ctx.globalAlpha = alpha;
    ctx.fillStyle = star.color;
    ctx.shadowColor = '#FFFFFF';
    ctx.shadowBlur = star.blur;

    if (star.shape === 'dust') {
      ctx.beginPath();
      ctx.arc(0, 0, star.size, 0, Math.PI * 2);
      ctx.fill();
    } else if (star.shape === 'four-point') {
      const outer = star.size * 1.45;
      const inner = star.size * 0.24;
      ctx.beginPath();
      for (let i = 0; i < 8; i += 1) {
        const radius = i % 2 === 0 ? outer : inner;
        const angle = (i * Math.PI) / 4;
        const px = Math.cos(angle) * radius;
        const py = Math.sin(angle) * radius;
        if (i === 0) ctx.moveTo(px, py);
        else ctx.lineTo(px, py);
      }
      ctx.closePath();
      ctx.fill();
    } else {
      // Delicate six-point sparkle
      const outer = star.size * 1.35;
      const inner = star.size * 0.22;
      ctx.beginPath();
      for (let i = 0; i < 12; i += 1) {
        const radius = i % 2 === 0 ? outer : inner;
        const angle = (i * Math.PI) / 6;
        const px = Math.cos(angle) * radius;
        const py = Math.sin(angle) * radius;
        if (i === 0) ctx.moveTo(px, py);
        else ctx.lineTo(px, py);
      }
      ctx.closePath();
      ctx.fill();
    }

    ctx.restore();
  }

  function renderFrame(now) {
    const dtSeconds = (now - lastTime) / 1000;
    const elapsedSeconds = (now - startTime) / 1000;
    lastTime = now;

    ctx.clearRect(0, 0, width, height);

    for (let i = 0; i < stars.length; i += 1) {
      const star = stars[i];
      const alpha = stepStarParticle(star, dtSeconds, elapsedSeconds, width, height);
      drawStar(star, alpha);
    }

    if (!reducedMotionQuery.matches && !document.hidden) {
      rafId = window.requestAnimationFrame(renderFrame);
    } else {
      rafId = null;
    }
  }

  function renderStaticField() {
    ctx.clearRect(0, 0, width, height);
    for (let i = 0; i < stars.length; i += 1) {
      drawStar(stars[i], stars[i].baseAlpha * 0.75);
    }
  }

  function startLoop() {
    if (reducedMotionQuery.matches) {
      renderStaticField();
      return;
    }
    if (rafId === null && !document.hidden) {
      lastTime = performance.now();
      rafId = window.requestAnimationFrame(renderFrame);
    }
  }

  function stopLoop() {
    if (rafId !== null) {
      window.cancelAnimationFrame(rafId);
      rafId = null;
    }
  }

  resizeCanvas();
  startLoop();

  window.addEventListener('resize', () => {
    resizeCanvas();
    if (reducedMotionQuery.matches) renderStaticField();
  });

  document.addEventListener('visibilitychange', () => {
    if (document.hidden) stopLoop();
    else startLoop();
  });

  reducedMotionQuery.addEventListener('change', () => {
    stopLoop();
    startLoop();
  });
}

/* ==========================================================================
   3. INTERACTIVE CANVAS SCRATCH-TO-REVEAL DATE CARD
   ========================================================================== */

function initScratchCard() {
  const card = document.getElementById('scratch-card');
  const canvas = document.getElementById('scratch-canvas');
  const instruction = document.getElementById('scratch-instruction');
  if (!card || !(canvas instanceof HTMLCanvasElement)) return;

  const ctx = canvas.getContext('2d', { willReadFrequently: true });
  if (!ctx) return;

  let isScratching = false;
  let isRevealed = false;
  let lastPoint = null;
  let strokeCount = 0;

  function paintSilverCoating() {
    const rect = card.getBoundingClientRect();
    const width = Math.max(1, Math.floor(rect.width));
    const height = Math.max(1, Math.floor(rect.height));

    canvas.width = width;
    canvas.height = height;

    ctx.globalCompositeOperation = 'source-over';

    // Metallic silver-grey scratch foil coating
    const grad = ctx.createLinearGradient(0, 0, width, height);
    grad.addColorStop(0, '#9fa4a8');
    grad.addColorStop(0.28, '#dde0e3');
    grad.addColorStop(0.54, '#92979b');
    grad.addColorStop(0.78, '#c5c9cc');
    grad.addColorStop(1, '#7f858a');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, width, height);

    // Subtle brushed foil horizontal grain
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.14)';
    ctx.lineWidth = 1;
    for (let y = 3; y < height; y += 5) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(width, y);
      ctx.stroke();
    }

    // Diagonal light reflection band
    const sheen = ctx.createLinearGradient(0, height * 0.15, width, height * 0.85);
    sheen.addColorStop(0, 'rgba(255, 255, 255, 0)');
    sheen.addColorStop(0.45, 'rgba(255, 255, 255, 0.22)');
    sheen.addColorStop(0.55, 'rgba(255, 255, 255, 0.04)');
    sheen.addColorStop(1, 'rgba(255, 255, 255, 0)');
    ctx.fillStyle = sheen;
    ctx.fillRect(0, 0, width, height);

    // Subtle engraved inner hairline border on the foil
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.35)';
    ctx.lineWidth = 1;
    ctx.strokeRect(10, 10, width - 20, height - 20);

    // Delicate embossed center diamond emblem on the foil surface
    const cx = width / 2;
    const cy = height / 2;
    ctx.save();
    ctx.translate(cx, cy);
    ctx.rotate(Math.PI / 4);
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.42)';
    ctx.lineWidth = 1.1;
    ctx.strokeRect(-14, -14, 28, 28);
    ctx.strokeStyle = 'rgba(65, 70, 75, 0.22)';
    ctx.strokeRect(-9, -9, 18, 18);
    ctx.restore();
  }

  function revealCard() {
    if (isRevealed) return;
    isRevealed = true;
    isScratching = false;
    card.dataset.scratched = 'true';
    canvas.setAttribute('aria-pressed', 'true');
    if (instruction) {
      instruction.textContent = 'Sunday, 20 December 2026';
    }
  }

  function checkCoverage() {
    if (isRevealed) return;
    const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    const coverage = computeScratchCoverage(imageData.data, 6);
    if (shouldAutoRevealScratch(coverage)) {
      revealCard();
    }
  }

  function getLocalPoint(clientX, clientY) {
    const rect = canvas.getBoundingClientRect();
    return {
      x: ((clientX - rect.left) / Math.max(1, rect.width)) * canvas.width,
      y: ((clientY - rect.top) / Math.max(1, rect.height)) * canvas.height,
    };
  }

  function scratchAt(point) {
    if (isRevealed) return;
    const brushRadius = Math.max(18, Math.round(canvas.width * 0.058));

    ctx.save();
    ctx.globalCompositeOperation = 'destination-out';
    ctx.fillStyle = '#000000';
    ctx.strokeStyle = '#000000';
    ctx.lineWidth = brushRadius * 2;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';

    if (lastPoint) {
      ctx.beginPath();
      ctx.moveTo(lastPoint.x, lastPoint.y);
      ctx.lineTo(point.x, point.y);
      ctx.stroke();
    } else {
      ctx.beginPath();
      ctx.arc(point.x, point.y, brushRadius, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.restore();

    lastPoint = point;
    strokeCount += 1;
    if (strokeCount % 6 === 0) {
      checkCoverage();
    }
  }

  canvas.addEventListener('pointerdown', (event) => {
    if (isRevealed) return;
    isScratching = true;
    lastPoint = null;
    if (canvas.setPointerCapture) {
      try {
        canvas.setPointerCapture(event.pointerId);
      } catch {
        // Ignore if pointer capture is unavailable
      }
    }
    scratchAt(getLocalPoint(event.clientX, event.clientY));
  });

  canvas.addEventListener('pointermove', (event) => {
    if (!isScratching || isRevealed) return;
    scratchAt(getLocalPoint(event.clientX, event.clientY));
  });

  function stopScratching() {
    if (!isScratching) return;
    isScratching = false;
    lastPoint = null;
    checkCoverage();
  }

  canvas.addEventListener('pointerup', stopScratching);
  canvas.addEventListener('pointercancel', stopScratching);

  // Keyboard accessibility for scratch card
  canvas.addEventListener('keydown', (event) => {
    if (event.key === 'Enter' || event.key === ' ') {
      event.preventDefault();
      revealCard();
    }
  });

  paintSilverCoating();

  if ('ResizeObserver' in window) {
    let lastWidth = card.clientWidth;
    const observer = new ResizeObserver(() => {
      if (!isRevealed && Math.abs(card.clientWidth - lastWidth) > 4) {
        lastWidth = card.clientWidth;
        paintSilverCoating();
      }
    });
    observer.observe(card);
  }
}

/* ==========================================================================
   4. LIVE COUNTDOWN TIMER (20 DECEMBER 2026, SUNDAY, 1:00 PM)
   ========================================================================== */

function initCountdown() {
  const daysEl = document.getElementById('countdown-days');
  const hoursEl = document.getElementById('countdown-hours');
  const minsEl = document.getElementById('countdown-mins');
  const secsEl = document.getElementById('countdown-secs');
  const passedEl = document.getElementById('countdown-passed-msg');

  if (!daysEl || !hoursEl || !minsEl || !secsEl) return;

  const targetDate = createWalimaTargetDate();

  function update() {
    const { days, hours, mins, secs, passed } = calculateCountdown(new Date(), targetDate);
    daysEl.textContent = padTwoDigits(days);
    hoursEl.textContent = padTwoDigits(hours);
    minsEl.textContent = padTwoDigits(mins);
    secsEl.textContent = padTwoDigits(secs);

    if (passedEl) {
      passedEl.hidden = !passed;
    }
  }

  update();
  const intervalId = window.setInterval(update, 1000);

  window.addEventListener('beforeunload', () => {
    window.clearInterval(intervalId);
  });
}

/* ==========================================================================
   BOOT APPLICATION
   ========================================================================== */

document.addEventListener('DOMContentLoaded', () => {
  const audioController = initBackgroundAudio();
  initCurtainCover(audioController);
  initStarfield();
  initScratchCard();
  initCountdown();
});
